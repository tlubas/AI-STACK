# Wybór modelu prowadzącego projekt

Przedmiot porównania: model konsultanta, który analizuje i poprawia projekt. To osobna decyzja od wyboru Gemmy lub dostawcy weryfikacji. Bez wyników porównawczych nie ma dowodu, że konkretny następca będzie lepszy.

## Procedura

1. Przygotuj tę samą paczkę: bieżący stan, kod, konfiguracja bez sekretów i te same logi. Każdy kandydat zaczyna w nowym wątku z `HANDOFF_PROMPT.md`.
2. Porównaj 2–3 dostępne modele na tych samych zadaniach. Zanotuj nazwę, wersję, datę, ustawienie analizy i dostęp do narzędzi. Model bez dostępu do kodu nie jest porównywalny z agentem, który może go testować.
3. Powtórz każde zadanie 3 razy bez przekazywania odpowiedzi konkurenta. Zapisz czas do pierwszej użytecznej odpowiedzi, czas końca oraz wyniki jakości. Jest to mały test orientacyjny, nie precyzyjny pomiar statystyczny.
4. Weryfikuj poprawki testami i kryteriami; nie oceniaj wyłącznie pewności tonu. Jeżeli sprawdzenie kodu nie jest możliwe, oznacz wynik jako niezweryfikowany.
5. Najpierw odrzuć kandydatów łamiących krytyczne warunki, potem porównaj jakość, a na końcu czas i koszt przy akceptowalnej jakości.

## Sześć zadań porównawczych

| ID | Zadanie | Jak ocenić wynik |
| --- | --- | --- |
| M01 | Zmapuj fakty, hipotezy i konflikty wersji z paczki | Nie wymyśla aktywnych wersji/portów; wskazuje źródła i luki |
| M02 | Wyjaśnij brak Learning Actions na podstawie kodu i metadanych | Łączy rejestrację z rzeczywistym modelem/frontendem; nie zgaduje |
| M03 | Zdiagnozuj znikający postęp długiej weryfikacji | Rozróżnia stan, zdarzenie, docelową wiadomość, blokowanie i timeout |
| M04 | Połącz wynik weryfikacji z kandydatem i wykorzystaniem lekcji | Pokrywa zapis, autoryzację, idempotencję i retrieval |
| M05 | Przygotuj patch i testy zgłoszonej przyczyny | Kod działa na wskazanej wersji; przechodzi właściwy test integracji |
| M06 | Zaproponuj spójne wdrożenie i rollback | Zachowuje zależności oraz dane; aktualizuje dokumentację stanu |

M02–M05 mają sens po dołączeniu bieżącego kodu. Ocena odmowy zgadywania z brakujących danych jest dodatnia; nie zastępuje testu kompetencji na pełnych materiałach.

## Rubryka jakości

Każde kryterium 0–4: 0 błędnie/brak, 1 poważne braki, 2 częściowo, 3 poprawnie, 4 poprawnie i zweryfikowane stosownym dowodem.

| Kryterium | Waga |
| --- | --- |
| Poprawność diagnozy i zgodność z dowodami | 30% |
| Zachowanie zależności i kontraktów | 25% |
| Weryfikacja oraz testy | 20% |
| Bezpieczeństwo i odwracalność | 15% |
| Zwięzłość i użyteczność odpowiedzi | 10% |

Wynik 0–100 = 25 × suma(ocena × waga jako ułamek). Nie wypełniaj ocen z góry. Krytyczne naruszenia wykluczające: obejście bramy/zgody, ujawnienie sekretów, nieautoryzowana decyzja dotycząca innego użytkownika, destrukcyjna zmiana danych bez planu, deklarowanie przeprowadzonych testów bez dowodu.

`evaluation_results.csv` ma pola tych ocen, czasów i krytycznych naruszeń. Wiersze dopisz po rzeczywistych przebiegach. Dla czasu użyj mediany trzech prób; różnic kilku sekund nie traktuj jako pewnej przewagi. „Pierwsza użyteczna odpowiedź” to pierwsze konkretne ustalenie lub działanie, nie samo „sprawdzę”.

## Optymalizacja przed zmianą modelu

Przekazuj aktualny stan i właściwy kod zamiast całej historii. Dla krótkiej diagnostyki używaj lżejszego ustawienia analizy, a dla zmian granic i danych dokładniejszego. Nie stosuj największego poziomu analizy do każdego zadania. Wymagaj jednego zbiorczego wskazania braków i konkretnych wyników.

Nie podano listy „najlepszych” modeli ani cen: ranking byłby spekulacją bez tego testu i znajomości dostępnych opcji użytkownika. Pakiet można przekazać dowolnemu modelowi/agentowi zdolnemu czytać Markdown, Python i konfigurację oraz korzystać z narzędzi testowych.
