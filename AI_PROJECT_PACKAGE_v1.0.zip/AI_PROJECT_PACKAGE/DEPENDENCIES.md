# Zależności i kontrakty

Opis logiczny. Fakty o aktywnych połączeniach należy uzupełnić na podstawie kodu i konfiguracji. Nie jest to wykaz potwierdzonych adresów sieciowych.

| Granica | Dane/odpowiedzialność | Co trzeba potwierdzić przed zmianą |
| --- | --- | --- |
| Open WebUI → AI Broker | Rozmowa, model, routing | Format żądania, streaming, role, identyfikacja użytkownika |
| Broker → lokalny runtime → Gemma | Generowanie lokalnej odpowiedzi | Rzeczywisty model, prompt, limity kontekstu, parametry, zasoby |
| Router → Broker | Decyzja o ścieżce | Reguły routingu, fallback, ograniczenia zgody i prywatności |
| Action weryfikacji → Broker | Źródłowa odpowiedź i prośba o sprawdzenie | Obsługa `/external/verify`, ID czatu/wiadomości, autoryzacja, timeout |
| Broker → Privacy Gateway → dostawca | Kontrolowana wysyłka zewnętrzna | Polityka redakcji, Approval Gate, limit danych i modele |
| Privacy Gateway → LiteLLM → dostawca | Pośrednictwo, jeśli jest wdrożone | Obecność warstwy i aliasów, normalizacja błędów |
| Wynik weryfikacji → Open WebUI/Chat Store | Raport i powiązanie z wiadomością | Kontrakt odpowiedzi Action, zapisywanie, odczyt po odświeżeniu |
| Wynik weryfikacji → Learning Store | Kandydat na lekcję | Czy zapis już istnieje, schemat i walidacja korekty, deduplikacja |
| Learning Actions → Learning Store | Zatwierdzenie/odrzucenie/szczegóły | Rejestracja akcji, ID przypadku, uprawnienia, konflikt decyzji |
| Learning Store → kontekst lokalnego zapytania | Zastosowanie lekcji | Retrieval, zakres użytkownika, ranking, budżet tokenów, audyt |
| Cały przepływ → obserwowalność | Dowód i pomiar czasu | Wspólny ID korelacji bez zapisywania poufnego payloadu |

## Inwarianty projektu

- Decyzja i wynik odnoszą się do konkretnej wersji wiadomości. Regeneracja nie może podpiąć starej korekty do nowej odpowiedzi.
- Trwały wynik i UI mają spójną informację o sukcesie. Przy częściowym zapisie system nie pokazuje ogólnego „wszystko zapisano”.
- Żądania jednego użytkownika nie mogą aktualizować czatu ani lekcji drugiego.
- Ponowienie po utracie odpowiedzi nie tworzy podwójnych raportów/przypadków.
- Kandydat na lekcję nie jest od razu wiedzą zatwierdzoną. Wybór i wykorzystanie lekcji muszą przestrzegać istniejącej polityki.
- Brak właściwej lekcji nie uruchamia ukrytego wysłania danych do dostawcy.
- Kontrole prywatności i dokumentów obowiązują również poprawki i kandydatów na lekcje.

## Proponowany minimalny kontrakt wewnętrzny — P

To lista pól do porównania z istniejącym kodem, nie instrukcja bezwarunkowej zmiany API. Zachować istniejące nazwy lub użyć adaptera.

| Obiekt | Potrzebne informacje |
| --- | --- |
| Żądanie | `request_id`, `chat_id`, `message_id`, wersja/hash wiadomości, tryb weryfikacji, model; użytkownik ustalany z uwierzytelnienia |
| Stan weryfikacji | `verification_id`, etap, znacznik czasu, stan końcowy i informacja o zapisie |
| Wynik | Raport/korekta, pochodzenie modelu, odniesienie do źródła, status walidacji |
| Kandydat na lekcję | `case_id`, `verification_id`, źródło, treść/kontekst zastosowania, status i zakres dostępu |
| Decyzja | `case_id`, zatwierdzenie/odrzucenie, uprawniony decydent, czas, wersja rekordu |
| Retrieval | ID wykorzystanych lekcji, powód wyboru, wersje, liczba tokenów; bez poufnej treści w logu |

Przykładowe etapy: `awaiting_approval`, `queued` jeśli jest kolejka, `running`, `saving`, `completed`, `failed`, `cancelled`. Sukces weryfikacji i sukces zapisu przypadku to odrębne wyniki; możliwy jest raport poprawny przy nieudanym zapisie lekcji. UI powinno to rozróżniać. `timeout` z perspektywy przeglądarki nie oznacza automatycznie anulowania pracy u dostawcy.

## Kontrakt widoczności akcji

Diagnoza ma przejść cały łańcuch: kod funkcji → rozpoznanie typu → aktywacja/uprawnienia → metadane wybranego modelu → żądanie przeglądarki → renderowanie przycisków. Dopiero potem bada się zachowanie kliknięcia i zapis decyzji.

Aktualna dokumentacja Open WebUI wskazuje klasę `Action`, listę podakcji na klasie/instancji, identyfikator istniejącej wiadomości w zwracanych aktualizacjach i aktywację globalną lub przy modelu. Porównanie z wersją zainstalowaną jest obowiązkowe. Przeczytanie funkcji z HTTP 200 nie potwierdza, że model udostępnił ją w UI.

Źródło: [Action Function — Open WebUI](https://docs.openwebui.com/features/extensibility/plugin/functions/action/), sprawdzone 2026-10-12; dokumentacja bieżąca, nie gwarancja zgodności starszej instalacji.
