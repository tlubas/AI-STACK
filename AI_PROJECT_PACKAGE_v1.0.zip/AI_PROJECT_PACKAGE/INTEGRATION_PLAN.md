# Plan optymalizacji i naprawy integracji

Plan obejmuje projekt jako całość. Zestawy mogą zawierać wiele plików i usług; ich zakres zależy od potwierdzonej przyczyny, nie od sztucznego limitu liczby zmian.

## Zestaw A — wiarygodny punkt odniesienia

Zebrać w jednej paczce: migawkę Docker, wdrożony kod, funkcje i Valves, przypisania modelu, kod Learning Store/retrieval i jeden przebieg z identyfikatorami. Powiązać obrazy z commitami albo hashami źródeł. Rozstrzygnąć, czy 0.1.5 jest rzeczywiście aktywna, jaki model stoi za Secure Auto i jaką wersję kontraktów obsługuje frontend.

Wynik: `AI_SYSTEM_STATE.md` wskazuje rzeczywisty stan, a niewiadome nie są przedstawiane jako wdrożone możliwości. Nie wymaga zmiany usług.

## Zestaw B — weryfikacja z czytelnym stanem i trwałym wynikiem

Dotknięte granice: Action, broker, brama, klient przeglądarki, Chat Store. Najpierw porównać identyfikatory docelowej wiadomości, format zwracanego wyniku, zdarzenia w przeglądarce i zapis w bazie.

Docelowo użytkownik widzi stan przy sprawdzanej odpowiedzi albo w trwałym panelu aż do zakończenia. Pokazujemy etap i czas oczekiwania. Jeśli dostawca nie podaje postępu, nie wymyślamy procentów. Zamknięcie karty nie powinno prowadzić do fałszywej informacji o sukcesie czy utraty już zapisanego raportu.

Sprawdzić, czy event loop nie jest blokowany synchronicznym wywołaniem HTTP. Sam timer nie pomoże przy zablokowanej pętli. Sprawdzić również granice timeoutów UI/reverse proxy/brokera/bramy/dostawcy i zachowanie ponowień.

Wybór rozwiązania po diagnozie: obsługiwane w tej wersji zdarzenia/aktualizacja wiadomości; jeśli wymaganie trwałego panelu nie mieści się w API funkcji, jawna zmiana frontendu. Osobny trwały job z odczytem stanu rozważyć dopiero, jeśli długie zadania i rozłączenia uzasadniają ten zakres. Nie zakładać, że samo powtarzanie popupów rozwiązuje wymaganie.

## Zestaw C — pełna ścieżka lekcji

Dotknięte granice: kod i rejestracja Learning Actions, metadane modelu, broker, zapis przypadków, walidacja/zgody i retrieval.

Ustalić osobno, dlaczego przyciski nie są wyświetlane i czy z weryfikacji powstaje przypadek. Nie uzależniać diagnozy rejestracji przycisków od istnienia `C-xxxx`. Naprawa ma dostarczyć widoczne akcje, prawidłowy przypadek, decyzję oraz wykazane użycie zatwierdzonej lekcji w nowym zapytaniu.

Kandydat musi mieć ślad pochodzenia i zakres zastosowania. Nie każdy raport ma tworzyć lekcję: wynik „bez korekty” nie powinien produkować pustego przypadku. Sprawdzić istniejące reguły walidacji, deduplikacji i konfliktów zanim doda się nowe.

## Zestaw D — jakość i czas odpowiedzi lokalnej

Najpierw zmierzyć osobno: kolejkę, routing, retrieval, budowę kontekstu, lokalną generację, weryfikację zewnętrzną i zapis. Podawać czas do pierwszego tokenu oraz czas końca; oddzielić zimny start od rozgrzanego modelu.

Sprawdzić, jaki prompt i parametry Gemma otrzymuje w shell oraz Open WebUI. Ustalić różnice kontekstu, limitów odpowiedzi, streamingu, narzędzi i lekcji. Wcześniejsze problemy stabilności nie uzasadniają przywrócenia starych ustawień bez danych.

Możliwe zmiany po pomiarze: mniej nieistotnego kontekstu, selektywne lekcje, poprawa routingu, kontrola współbieżności i parametrów. Zamiana workera wymaga porównania na tym samym sprzęcie i zadaniach. Nie dodawać n8n ani kolejnych warstw tylko dla porządku dokumentacji.

## Zestaw E — sprawniejsza praca konsultanta lub przekazanie

Wspólny stan i kod zastępują wielokrotne odczyty długiej historii. Osobne krótkie wątki mogą obsługiwać podsystemy, lecz raportują do tej samej dokumentacji. Każdy model dostaje ten sam snapshot; brakujące dane zgłasza zbiorczo. Wybór nowego modelu według `MODEL_EVALUATION.md` nie zmienia systemu produkcyjnego.

## Warunki wdrożenia każdego zestawu

Przed wdrożeniem zapisać obrazy/commity, eksport funkcji i Valves oraz sprawdzony sposób przywrócenia danych. Nie wykonywać kopii aktywnej bazy przez przypadkowe kopiowanie plików — metoda zależy od silnika.

Preferować zmiany zgodne wstecz: najpierw odbiorca nowego kontraktu, potem jego nadawca; stare pole/ścieżkę usuwać dopiero po sprawdzeniu wszystkich klientów. Jeśli to niemożliwe, opisać skoordynowane okno zmiany. W razie migracji lekcji rollback musi uwzględnić decyzje dodane po wdrożeniu, nie tylko przywrócić stary kod.

Każdy zestaw kończy się testami zależnych granic, przepływu i regresji z `ACCEPTANCE_TESTS.md`. Przy wyniku negatywnym zapisać dowody i poprawić przyczynę; nie wydawać kolejnej wersji tylko po to, aby ponowić ten sam eksperyment.
