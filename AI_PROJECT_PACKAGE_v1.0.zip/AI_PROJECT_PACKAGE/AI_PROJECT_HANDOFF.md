# Projekt AI — dokument przekazania i optymalizacji

Wersja 1.0 | 2026-10-12

Gotowy kontekst dla nowego modelu lub wątku. Stan opisano na podstawie dostępnych rozmów; aktywny kod i serwer nie zostały odczytane. Zmiany projektujemy jako spójne zestawy obejmujące zależności. To nie jest deklaracja naprawy systemu.

Do użycia: wklej sekcję „Instrukcje projektu AI” w ustawienia projektu, dołącz ten dokument do nowego wątku i użyj sekcji „Prompt startowy”. Do diagnozy kodu dołącz materiały z „Materiały do diagnozy i przekazania kodu”. Archiwum zawiera osobne dokumenty, skrypt diagnostyczny i pusty arkusz wyników.

# AI_SYSTEM_STATE

Data: 2026-10-12. Stan wiedzy z rozmowy, bez odczytu bieżącego serwera.

## Oznaczenia wiarygodności

| Oznaczenie | Znaczenie |
| --- | --- |
| U | Obserwacja zgłoszona przez użytkownika; niepowtórzona w tym środowisku |
| L | Fragment logu widoczny w kontekście; dowodzi wyłącznie zawartego zdarzenia |
| H | Historyczny opis lub propozycja wcześniejszego asystenta; wymaga weryfikacji |
| P | Nowa propozycja docelowa; nie jest wdrożoną funkcją |
| ? | Brak danych lub brak rozstrzygnięcia |

Historyczny opis asystenta nie jest dowodem aktualnego kodu. Zgłoszony brak przycisków nie dowodzi braku przypadków w bazie. Odpowiedź zewnętrzna nie dowodzi zapisania lekcji ani jej użycia przez Gemmę.

## Cel i ograniczenia

Lokalny system AI ma udzielać użytecznych odpowiedzi, zapewniać kontrolowaną weryfikację zewnętrzną oraz korzystać z zatwierdzonych korekt. Użytkownik oczekuje krótkiej, sprawnej pracy technicznej i zmian obejmujących cały wymagany zakres zależności. Priorytety: poprawność, bezpieczeństwo, stabilność, szybkość. Dotychczasowe wielokrotne poprawki funkcji bez potwierdzenia przyczyn nie przyniosły oczekiwanego wyniku.

## Komponenty

| Komponent | Rola wynikająca z rozmów | Stan/version evidence |
| --- | --- | --- |
| Open WebUI | Czat, funkcje Action, wyświetlanie raportu i decyzji | Komponent obecny; aktywna wersja ? |
| AI Broker | Orkiestracja lokalnego i zewnętrznego przetwarzania | H: 0.2.8 wymienione w opisie z 2026-10-09; aktywna wersja ? |
| Privacy Gateway | Kontrola danych wysyłanych zewnętrznie | H: 0.6.6 wymienione w opisie z 2026-10-09; aktywna wersja ? |
| LiteLLM | Pośrednictwo do modeli zewnętrznych | H: element opisanej architektury; obecność/wersja ? |
| Lokalny worker Gemma | Generowanie odpowiedzi lokalnych | H: Gemma3:12B; dokładny alias, kwantyzacja i parametry ? |
| Lokalny router | Wybór ścieżki obsługi | H: qwen2.5:1.5b; wdrożone reguły ? |
| Learning Store | Przypadki, zatwierdzenia, lekcje | Wymieniony w projekcie; schemat, lokalizacja i retrieval ? |
| OpenAI | Zewnętrzna weryfikacja i korekta | U: odpowiedź dotarła i była poprawna; dokładny model ? |
| Chat Store | Trwałe zapisanie wyniku w rozmowie | H: mechanizm wspominany w poprzednich poprawkach; sposób zapisu ? |

Nie ustalono nazw repozytoriów, nazw wszystkich kontenerów, portów, reverse proxy, rodzaju bazy ani montowań danych. Nie należy podstawiać wartości z typowych instalacji.

## Aktualne problemy

| ID | Dostępny dowód | Wniosek i niewiadoma |
| --- | --- | --- |
| EXT-RESULT | U: wcześniej powiadomienia bez efektu; później odpowiedź OpenAI dotarła | Co najmniej jeden przebieg zewnętrzny zakończył się wynikiem; trwałość po odświeżeniu ? |
| EXT-PROGRESS | U: popup oczekiwania znika; informacje bywały pod tytułem czatu; nadal brak oczekiwanego postępu | Nie potwierdzono czytelnego wskaźnika działającego przez cały czas |
| LEARN-BUTTONS | U: nadal brak przycisków zatwierdzania lekcji | Trzeba prześledzić kod → aktywację → metadane modelu → frontend |
| LEARN-LINK | H: wcześniejszy asystent stwierdził brak połączenia `/external/verify` z tworzeniem przypadku | Hipoteza, nie wynik audytu kodu; sprawdzić przed dopisywaniem zapisu |
| LOCAL-QUALITY | U: Gemma podaje błędne, zmienne odpowiedzi | Przyczyna ?; ustawienia, kontekst, retrieval i jakość modelu do rozdzielenia |
| WORKFLOW-SPEED | U: odpowiedzi asystenta prowadzącego projekt są zbyt wolne | Ograniczyć odtwarzanie historii i zbędną pracę; nie utożsamiać z opóźnieniem Gemmy |
| DOC-FIREWALL | U: firewall dokumentowy działa i nie wykonuje instrukcji z dokumentu | Zachować jako obowiązkową regresję |

## Historia funkcji

`Secure Auto External Verification`: wcześniejsze propozycje 0.1.1–0.1.5. Ostatnia opisana propozycja: 0.1.5, Valves `progress_ui_mode=inline`, `progress_interval_seconds=10`. Nie potwierdzono aktualnie aktywnego kodu ani zapisanych wartości Valves.

`Secure Auto Learning Actions`: historycznie wymieniono 0.1.3 oraz działania Zatwierdź, Odrzuć, Szczegóły. Nie potwierdzono struktury klasy, metadanych, przypisań do modelu ani aktywacji Global. Użytkownik zgłosił utrzymujący się brak przycisków.

L: widoczny fragment logu zawiera odpowiedź HTTP 200 na toggle `secure_auto_action_labels`, odczyt `secure_auto_learning_actions` i komunikat załadowania modułu `function_secure_auto_learning_actions`. To dowodzi obsługi tych żądań/załadowania modułu w tym momencie; nie dowodzi poprawnej listy akcji wysyłanej do przeglądarki ani wyświetlenia przycisków. `secure_auto_action_labels` i `secure_auto_learning_actions` to różne identyfikatory.

## Wymagany przepływ docelowy — P

1. Odpowiedź lokalna powiązana z konkretnym użytkownikiem, czatem i wiadomością.
2. Żądanie weryfikacji objęte istniejącymi kontrolami prywatności i zgody.
3. Czytelny stan oczekiwania przy sprawdzanej odpowiedzi aż do wyniku/błędu/anulowania.
4. Wynik zewnętrzny trwale powiązany z odpowiedzią źródłową.
5. Korekta wymagająca lekcji tworzy kandydata po walidacji, bez automatycznego zatwierdzenia.
6. Uprawniony użytkownik zatwierdza albo odrzuca właściwy przypadek.
7. Zatwierdzona lekcja jest pobierana do odpowiedniego przyszłego zapytania i jej użycie można wykazać.

Nie zakładamy treningu wag Gemmy. Dopóki kod nie pokaże inaczej, „uczenie” oznacza zapamiętanie i użycie zatwierdzonej wiedzy przez mechanizm kontekstu/retrieval. Sam zapis `approved` nie zmienia modelu.

## Najważniejsze brakujące dane

Aktywne źródła funkcji i Valves; wersja Open WebUI; metadane rzeczywiście wybranego modelu; obsługa `/external/verify`; kod Learning Store i wstrzykiwania lekcji; konfiguracja usług bez sekretów; jeden powtarzalny przebieg z czasami i identyfikatorami. Pełna lista w `SOURCE_INPUTS.md`.

Po każdym wdrożeniu aktualizować ten plik: wersja/commit → zmiana → dowód testu → nierozstrzygnięte kwestie. Nie usuwać negatywnych wyników testów ani mieszać propozycji ze stanem wdrożonym.

---

# Instrukcje projektu AI — do wklejenia

Jesteś głównym konsultantem technicznym lokalnego systemu AI. Prowadź projekt po polsku, zwięźle i konkretnie. Celem jest poprawny system obejmujący Open WebUI, AI Broker, Privacy Gateway, modele lokalne, weryfikację zewnętrzną i Learning Store.

1. Zacznij od `AI_SYSTEM_STATE.md`, `DEPENDENCIES.md`, rejestru zmian i aktualnego kodu. Używaj historii rozmów tylko do uzupełnienia braków. W razie konfliktu rozróżnij bieżące wdrożenie, historyczną propozycję i hipotezę; nie wybieraj wersji wyłącznie dlatego, że ma wyższy numer.
2. Projektuj spójne zestawy zmian obejmujące wszystkie wymagane komponenty. Nie ograniczaj pracy do jednej zmiany lub jednego pliku na raz. Granicę zestawu wyznacza wspólny rezultat i możliwość bezpiecznego wycofania.
3. Przed poprawką zbierz dowody pozwalające rozróżnić istotne przyczyny. Jeżeli brak kodu, logów lub konfiguracji, przygotuj dokładną diagnostykę i oznacz hipotezy. Nie wydawaj kolejnych numerowanych wersji na podstawie samego przypuszczenia.
4. Dla każdego zestawu zmian zapisz: cel, dotknięte komponenty, zmienione kontrakty, wpływ na dane, kolejność wdrożenia, test całego przepływu oraz sposób wycofania. Jeśli migracja bazy utrudnia rollback, podaj to przed wdrożeniem.
5. Zachowaj istniejące kontrole prywatności, zgody, uprawnień, izolacji użytkowników i firewall dokumentowy. Nie omijaj ich dla skrócenia czasu ani ułatwienia integracji.
6. Testuj szczególnie granice UI/API/model/baza: identyfikatory wiadomości, zapis i odczyt, timeout, przerwanie, ponowienie i duplikaty. Test jednostkowy nie zastępuje dowodu działania w Open WebUI.
7. Nie deklaruj sukcesu bez wyniku testu. Rozróżniaj „kod sprawdzony lokalnie”, „wdrożony”, „potwierdzony w UI” i „potwierdzony po restarcie”. Jawnie podaj, czego nie sprawdzono.
8. Nie nazywaj zapisu lekcji treningiem modelu. Sprawdź, jak lekcja jest dobierana i dołączana do przyszłego kontekstu, i czy otrzymuje ją właściwy użytkownik.
9. Ogranicz powtarzanie architektury, szerokie wyszukiwania oraz pliki bez konkretnego zastosowania. Przy pytaniu technicznym odczytaj tylko zależny kod i dokumentację wersji używanej w projekcie. Sprawdzaj źródła aktualnych lub niepewnych informacji.
10. Dostosuj głębokość analizy do zadania. Krótką diagnostykę obsługuj sprawnie; zmiany kontraktów i danych wymagają dokładniejszej analizy. Nie obiecuj stałego czasu odpowiedzi ani przewagi modelu bez pomiaru.
11. Odpowiedź robocza ma podać: ustalenie, dowód, następne działanie i oczekiwany wynik. Komendy muszą być gotowe do wykonania albo mieć jednoznacznie opisane miejsca do zastąpienia. Nie zgaduj nazw kontenerów, portów i ścieżek.
12. Utrzymuj dokumentację stanu oraz rejestr zmian równocześnie z kodem. Nowy wątek może dotyczyć podsystemu, lecz każde rozstrzygnięcie aktualizuje wspólny stan i mapę zależności.
13. Nie wracaj do odrzuconych rozwiązań bez nowego dowodu. Nie powtarzaj Active+Global jako pełnej diagnozy, gdy użytkownik zgłasza, że poprzednie działania nie pomogły.
14. Pracuj autonomicznie w uzgodnionym zakresie. Pytaj tylko o informacje, których brak zmienia rozwiązanie, lub wymagane zgody. Zbierz brakujące dane w jeden uporządkowany pakiet zamiast wielu pojedynczych pytań.

Priorytety: poprawność → bezpieczeństwo → stabilność → szybkość. Szybkość zwiększaj przez lepszy kontekst, właściwy zakres i pomiary; nie przez pomijanie zależności lub testów.

---

# Zależności i kontrakty

Opis logiczny. Fakty o aktywnych połączeniach należy uzupełnić na podstawie kodu i konfiguracji. Nie jest to wykaz potwierdzonych adresów sieciowych.

| Granica | Dane/odpowiedzialność | Co trzeba potwierdzić przed zmianą |
| --- | --- | --- |
| Open WebUI → AI Broker | Rozmowa, model, routing | Format żądania, streaming, role, identyfikacja użytkownika |
| Broker → lokalny runtime → Gemma | Generowanie lokalnej odpowiedzi | Rzeczywisty model, prompt, limity kontekstu, parametry, zasoby |
| Router → Broker | Decyzja o ścieżce | Reguły routingu, fallback, ograniczenia zgody i prywatności |
| Action weryfikacji → Broker | Źródłowa odpowiedź i prośba o sprawdzenie | Obsługa `/external/verify`, ID czatu/wiadomości, autoryzacja, timeout |
| Broker → Privacy Gateway → dostawca | Kontrolowana wysyłka zewnętrzna | Polityka redakcji, Approval Gate, limit danych i modele |
| Privacy Gateway → LiteLLM → dostawca | Pośrednictwo, jeśli jest wdrożone | Obecność warstwy i aliasów, normalizacja błędów |
| Wynik weryfikacji → Open WebUI/Chat Store | Raport i powiązanie z wiadomością | Kontrakt odpowiedzi Action, zapisywanie, odczyt po odświeżeniu |
| Wynik weryfikacji → Learning Store | Kandydat na lekcję | Czy zapis już istnieje, schemat i walidacja korekty, deduplikacja |
| Learning Actions → Learning Store | Zatwierdzenie/odrzucenie/szczegóły | Rejestracja akcji, ID przypadku, uprawnienia, konflikt decyzji |
| Learning Store → kontekst lokalnego zapytania | Zastosowanie lekcji | Retrieval, zakres użytkownika, ranking, budżet tokenów, audyt |
| Cały przepływ → obserwowalność | Dowód i pomiar czasu | Wspólny ID korelacji bez zapisywania poufnego payloadu |

## Inwarianty projektu

- Decyzja i wynik odnoszą się do konkretnej wersji wiadomości. Regeneracja nie może podpiąć starej korekty do nowej odpowiedzi.
- Trwały wynik i UI mają spójną informację o sukcesie. Przy częściowym zapisie system nie pokazuje ogólnego „wszystko zapisano”.
- Żądania jednego użytkownika nie mogą aktualizować czatu ani lekcji drugiego.
- Ponowienie po utracie odpowiedzi nie tworzy podwójnych raportów/przypadków.
- Kandydat na lekcję nie jest od razu wiedzą zatwierdzoną. Wybór i wykorzystanie lekcji muszą przestrzegać istniejącej polityki.
- Brak właściwej lekcji nie uruchamia ukrytego wysłania danych do dostawcy.
- Kontrole prywatności i dokumentów obowiązują również poprawki i kandydatów na lekcje.

## Proponowany minimalny kontrakt wewnętrzny — P

To lista pól do porównania z istniejącym kodem, nie instrukcja bezwarunkowej zmiany API. Zachować istniejące nazwy lub użyć adaptera.

| Obiekt | Potrzebne informacje |
| --- | --- |
| Żądanie | `request_id`, `chat_id`, `message_id`, wersja/hash wiadomości, tryb weryfikacji, model; użytkownik ustalany z uwierzytelnienia |
| Stan weryfikacji | `verification_id`, etap, znacznik czasu, stan końcowy i informacja o zapisie |
| Wynik | Raport/korekta, pochodzenie modelu, odniesienie do źródła, status walidacji |
| Kandydat na lekcję | `case_id`, `verification_id`, źródło, treść/kontekst zastosowania, status i zakres dostępu |
| Decyzja | `case_id`, zatwierdzenie/odrzucenie, uprawniony decydent, czas, wersja rekordu |
| Retrieval | ID wykorzystanych lekcji, powód wyboru, wersje, liczba tokenów; bez poufnej treści w logu |

Przykładowe etapy: `awaiting_approval`, `queued` jeśli jest kolejka, `running`, `saving`, `completed`, `failed`, `cancelled`. Sukces weryfikacji i sukces zapisu przypadku to odrębne wyniki; możliwy jest raport poprawny przy nieudanym zapisie lekcji. UI powinno to rozróżniać. `timeout` z perspektywy przeglądarki nie oznacza automatycznie anulowania pracy u dostawcy.

## Kontrakt widoczności akcji

Diagnoza ma przejść cały łańcuch: kod funkcji → rozpoznanie typu → aktywacja/uprawnienia → metadane wybranego modelu → żądanie przeglądarki → renderowanie przycisków. Dopiero potem bada się zachowanie kliknięcia i zapis decyzji.

Aktualna dokumentacja Open WebUI wskazuje klasę `Action`, listę podakcji na klasie/instancji, identyfikator istniejącej wiadomości w zwracanych aktualizacjach i aktywację globalną lub przy modelu. Porównanie z wersją zainstalowaną jest obowiązkowe. Przeczytanie funkcji z HTTP 200 nie potwierdza, że model udostępnił ją w UI.

Źródło: [Action Function — Open WebUI](https://docs.openwebui.com/features/extensibility/plugin/functions/action/), sprawdzone 2026-10-12; dokumentacja bieżąca, nie gwarancja zgodności starszej instalacji.

---

# Plan optymalizacji i naprawy integracji

Plan obejmuje projekt jako całość. Zestawy mogą zawierać wiele plików i usług; ich zakres zależy od potwierdzonej przyczyny, nie od sztucznego limitu liczby zmian.

## Zestaw A — wiarygodny punkt odniesienia

Zebrać w jednej paczce: migawkę Docker, wdrożony kod, funkcje i Valves, przypisania modelu, kod Learning Store/retrieval i jeden przebieg z identyfikatorami. Powiązać obrazy z commitami albo hashami źródeł. Rozstrzygnąć, czy 0.1.5 jest rzeczywiście aktywna, jaki model stoi za Secure Auto i jaką wersję kontraktów obsługuje frontend.

Wynik: `AI_SYSTEM_STATE.md` wskazuje rzeczywisty stan, a niewiadome nie są przedstawiane jako wdrożone możliwości. Nie wymaga zmiany usług.

## Zestaw B — weryfikacja z czytelnym stanem i trwałym wynikiem

Dotknięte granice: Action, broker, brama, klient przeglądarki, Chat Store. Najpierw porównać identyfikatory docelowej wiadomości, format zwracanego wyniku, zdarzenia w przeglądarce i zapis w bazie.

Docelowo użytkownik widzi stan przy sprawdzanej odpowiedzi albo w trwałym panelu aż do zakończenia. Pokazujemy etap i czas oczekiwania. Jeśli dostawca nie podaje postępu, nie wymyślamy procentów. Zamknięcie karty nie powinno prowadzić do fałszywej informacji o sukcesie czy utraty już zapisanego raportu.

Sprawdzić, czy event loop nie jest blokowany synchronicznym wywołaniem HTTP. Sam timer nie pomoże przy zablokowanej pętli. Sprawdzić również granice timeoutów UI/reverse proxy/brokera/bramy/dostawcy i zachowanie ponowień.

Wybór rozwiązania po diagnozie: obsługiwane w tej wersji zdarzenia/aktualizacja wiadomości; jeśli wymaganie trwałego panelu nie mieści się w API funkcji, jawna zmiana frontendu. Osobny trwały job z odczytem stanu rozważyć dopiero, jeśli długie zadania i rozłączenia uzasadniają ten zakres. Nie zakładać, że samo powtarzanie popupów rozwiązuje wymaganie.

## Zestaw C — pełna ścieżka lekcji

Dotknięte granice: kod i rejestracja Learning Actions, metadane modelu, broker, zapis przypadków, walidacja/zgody i retrieval.

Ustalić osobno, dlaczego przyciski nie są wyświetlane i czy z weryfikacji powstaje przypadek. Nie uzależniać diagnozy rejestracji przycisków od istnienia `C-xxxx`. Naprawa ma dostarczyć widoczne akcje, prawidłowy przypadek, decyzję oraz wykazane użycie zatwierdzonej lekcji w nowym zapytaniu.

Kandydat musi mieć ślad pochodzenia i zakres zastosowania. Nie każdy raport ma tworzyć lekcję: wynik „bez korekty” nie powinien produkować pustego przypadku. Sprawdzić istniejące reguły walidacji, deduplikacji i konfliktów zanim doda się nowe.

## Zestaw D — jakość i czas odpowiedzi lokalnej

Najpierw zmierzyć osobno: kolejkę, routing, retrieval, budowę kontekstu, lokalną generację, weryfikację zewnętrzną i zapis. Podawać czas do pierwszego tokenu oraz czas końca; oddzielić zimny start od rozgrzanego modelu.

Sprawdzić, jaki prompt i parametry Gemma otrzymuje w shell oraz Open WebUI. Ustalić różnice kontekstu, limitów odpowiedzi, streamingu, narzędzi i lekcji. Wcześniejsze problemy stabilności nie uzasadniają przywrócenia starych ustawień bez danych.

Możliwe zmiany po pomiarze: mniej nieistotnego kontekstu, selektywne lekcje, poprawa routingu, kontrola współbieżności i parametrów. Zamiana workera wymaga porównania na tym samym sprzęcie i zadaniach. Nie dodawać n8n ani kolejnych warstw tylko dla porządku dokumentacji.

## Zestaw E — sprawniejsza praca konsultanta lub przekazanie

Wspólny stan i kod zastępują wielokrotne odczyty długiej historii. Osobne krótkie wątki mogą obsługiwać podsystemy, lecz raportują do tej samej dokumentacji. Każdy model dostaje ten sam snapshot; brakujące dane zgłasza zbiorczo. Wybór nowego modelu według `MODEL_EVALUATION.md` nie zmienia systemu produkcyjnego.

## Warunki wdrożenia każdego zestawu

Przed wdrożeniem zapisać obrazy/commity, eksport funkcji i Valves oraz sprawdzony sposób przywrócenia danych. Nie wykonywać kopii aktywnej bazy przez przypadkowe kopiowanie plików — metoda zależy od silnika.

Preferować zmiany zgodne wstecz: najpierw odbiorca nowego kontraktu, potem jego nadawca; stare pole/ścieżkę usuwać dopiero po sprawdzeniu wszystkich klientów. Jeśli to niemożliwe, opisać skoordynowane okno zmiany. W razie migracji lekcji rollback musi uwzględnić decyzje dodane po wdrożeniu, nie tylko przywrócić stary kod.

Każdy zestaw kończy się testami zależnych granic, przepływu i regresji z `ACCEPTANCE_TESTS.md`. Przy wyniku negatywnym zapisać dowody i poprawić przyczynę; nie wydawać kolejnej wersji tylko po to, aby ponowić ten sam eksperyment.

---

# Kryteria odbioru i regresji

Plan testów; żadnego z poniższych wyników nie potwierdzono w tej rozmowie. Wykonać na reprezentatywnym środowisku z syntetycznymi danymi. Do testów UI korzystać z faktycznego konta i modelu użytkownika. Testy izolacji wymagają dwóch kont kontrolowanych przez wykonującego test.

| ID | Scenariusz | Oczekiwany wynik/dowód |
| --- | --- | --- |
| T01 | Nowa odpowiedź Secure Auto | Widoczne Zatwierdź/Odrzuć/Szczegóły; zidentyfikowane metadane modelu i funkcji |
| T02 | Akcja przy odpowiedzi bez przypadku | Jasny komunikat o braku kandydata; brak błędnego zapisu decyzji |
| T03 | Zewnętrzna odpowiedź po kontrolowanym opóźnieniu ok. 60 s | Stan widoczny przy wiadomości/panelu przez całe oczekiwanie; etap/czas aktualizowany, brak zmyślonego procentu |
| T04 | Wynik zewnętrzny i odświeżenie czatu | Raport pozostaje przy właściwej odpowiedzi; brak duplikatu i uszkodzenia pierwotnej treści |
| T05 | Błąd/timeout dostawcy | Stan końcowy czytelny, bez fałszywego sukcesu; pierwotna odpowiedź zachowana |
| T06 | Raport zawiera uzasadnioną korektę | Jeden poprawny kandydat według polityki, z powiązaniem źródła i raportu |
| T07 | Raport nie wymaga korekty | Brak pustej lekcji; właściwy wynik dla użytkownika |
| T08 | Ponowne kliknięcie/ponowienie żądania | Kontrolowane zachowanie; bez dwóch przypadków dla tego samego wyniku |
| T09 | Zatwierdzenie i ponowny odczyt | Stan zatwierdzony jest trwały, decyzja ma właściwego autora i źródło |
| T10 | Nowe podobne pytanie po zatwierdzeniu | Audyt potwierdza pobranie właściwej lekcji; ocena treści odpowiedzi oddzielona od samego retrieval |
| T11 | Odrzucona albo niezwiązana lekcja | Nie trafia do kontekstu jako obowiązująca zatwierdzona wiedza |
| T12 | Użytkownik B podaje ID czatu/przypadku A | Brak dostępu i zmiany danych A; brak ujawnienia treści |
| T13 | Regeneracja/edycja po rozpoczęciu weryfikacji | Wynik pozostaje związany ze źródłową wersją albo jest oznaczony jako nieaktualny |
| T14 | Rozłączenie karty w trakcie i powrót | Rzeczywisty stan możliwy do odtworzenia; brak fałszywego „zakończono” |
| T15 | Zapis lekcji nieudany przy poprawnym raporcie | Raport dostępny, ale UI ujawnia problem zapisu; ponowienie nie powiela wyników |
| T16 | Restart po zakończonym zapisie | Raport, przypadek i decyzja nadal istnieją i dają się odczytać |
| R01 | Tryb lokalny/bez zgody na wysyłkę | Brak nieautoryzowanej transmisji zewnętrznej |
| R02 | Dokument z próbą zmiany instrukcji systemu | Zachowanie istniejącego firewalla dokumentowego |
| R03 | Dane testowe podlegające redakcji | Brama nadal stosuje uzgodnioną politykę danych |
| R04 | Te same zadania shell vs WebUI | Zebrane rzeczywiste prompty i parametry bez sekretów; brak nowej niestabilności |
| R05 | Bazowe zadania przed/po na tym samym sprzęcie | Czas i jakość porównane przy równych warunkach; oddzielne zimne/rozgrzane przebiegi |

Do T03 użyć kontrolowanego opóźnienia w środowisku testowym. Nie obniżać stabilności produkcji ani obciążać płatnego dostawcy tylko do symulacji wolnego wyniku.

## Minimalny zapis wyniku

Każdy test: wersje/commity, konfiguracja, data i czas, ID korelacji, wejście syntetyczne, kroki, oczekiwany wynik, obserwowany wynik, PASS/FAIL/NOT RUN oraz ograniczenia. Logi zapisują etapy i identyfikatory; treść poufną zastąpić syntetycznym odpowiednikiem.

Przejście retrieval nie gwarantuje odpowiedzi poprawnej. W T10 ocenić osobno, czy lekcja została użyta i czy Gemma poprawnie ją zastosowała. Samo istnienie przycisku nie potwierdza autoryzacji ani zapisu decyzji.

Minimalny odbiór zgłoszonych problemów obejmuje T01–T16 i R01–R03 w zakresie zmienionego przepływu. Testy jakości/parametrów dodaje się przy zmianach generacji. Niewykonanych testów nie oznaczać jako zaliczone.

---

# Wybór modelu prowadzącego projekt

Przedmiot porównania: model konsultanta, który analizuje i poprawia projekt. To osobna decyzja od wyboru Gemmy lub dostawcy weryfikacji. Bez wyników porównawczych nie ma dowodu, że konkretny następca będzie lepszy.

## Procedura

1. Przygotuj tę samą paczkę: bieżący stan, kod, konfiguracja bez sekretów i te same logi. Każdy kandydat zaczyna w nowym wątku z `HANDOFF_PROMPT.md`.
2. Porównaj 2–3 dostępne modele na tych samych zadaniach. Zanotuj nazwę, wersję, datę, ustawienie analizy i dostęp do narzędzi. Model bez dostępu do kodu nie jest porównywalny z agentem, który może go testować.
3. Powtórz każde zadanie 3 razy bez przekazywania odpowiedzi konkurenta. Zapisz czas do pierwszej użytecznej odpowiedzi, czas końca oraz wyniki jakości. Jest to mały test orientacyjny, nie precyzyjny pomiar statystyczny.
4. Weryfikuj poprawki testami i kryteriami; nie oceniaj wyłącznie pewności tonu. Jeżeli sprawdzenie kodu nie jest możliwe, oznacz wynik jako niezweryfikowany.
5. Najpierw odrzuć kandydatów łamiących krytyczne warunki, potem porównaj jakość, a na końcu czas i koszt przy akceptowalnej jakości.

## Sześć zadań porównawczych

| ID | Zadanie | Jak ocenić wynik |
| --- | --- | --- |
| M01 | Zmapuj fakty, hipotezy i konflikty wersji z paczki | Nie wymyśla aktywnych wersji/portów; wskazuje źródła i luki |
| M02 | Wyjaśnij brak Learning Actions na podstawie kodu i metadanych | Łączy rejestrację z rzeczywistym modelem/frontendem; nie zgaduje |
| M03 | Zdiagnozuj znikający postęp długiej weryfikacji | Rozróżnia stan, zdarzenie, docelową wiadomość, blokowanie i timeout |
| M04 | Połącz wynik weryfikacji z kandydatem i wykorzystaniem lekcji | Pokrywa zapis, autoryzację, idempotencję i retrieval |
| M05 | Przygotuj patch i testy zgłoszonej przyczyny | Kod działa na wskazanej wersji; przechodzi właściwy test integracji |
| M06 | Zaproponuj spójne wdrożenie i rollback | Zachowuje zależności oraz dane; aktualizuje dokumentację stanu |

M02–M05 mają sens po dołączeniu bieżącego kodu. Ocena odmowy zgadywania z brakujących danych jest dodatnia; nie zastępuje testu kompetencji na pełnych materiałach.

## Rubryka jakości

Każde kryterium 0–4: 0 błędnie/brak, 1 poważne braki, 2 częściowo, 3 poprawnie, 4 poprawnie i zweryfikowane stosownym dowodem.

| Kryterium | Waga |
| --- | --- |
| Poprawność diagnozy i zgodność z dowodami | 30% |
| Zachowanie zależności i kontraktów | 25% |
| Weryfikacja oraz testy | 20% |
| Bezpieczeństwo i odwracalność | 15% |
| Zwięzłość i użyteczność odpowiedzi | 10% |

Wynik 0–100 = 25 × suma(ocena × waga jako ułamek). Nie wypełniaj ocen z góry. Krytyczne naruszenia wykluczające: obejście bramy/zgody, ujawnienie sekretów, nieautoryzowana decyzja dotycząca innego użytkownika, destrukcyjna zmiana danych bez planu, deklarowanie przeprowadzonych testów bez dowodu.

`evaluation_results.csv` ma pola tych ocen, czasów i krytycznych naruszeń. Wiersze dopisz po rzeczywistych przebiegach. Dla czasu użyj mediany trzech prób; różnic kilku sekund nie traktuj jako pewnej przewagi. „Pierwsza użyteczna odpowiedź” to pierwsze konkretne ustalenie lub działanie, nie samo „sprawdzę”.

## Optymalizacja przed zmianą modelu

Przekazuj aktualny stan i właściwy kod zamiast całej historii. Dla krótkiej diagnostyki używaj lżejszego ustawienia analizy, a dla zmian granic i danych dokładniejszego. Nie stosuj największego poziomu analizy do każdego zadania. Wymagaj jednego zbiorczego wskazania braków i konkretnych wyników.

Nie podano listy „najlepszych” modeli ani cen: ranking byłby spekulacją bez tego testu i znajomości dostępnych opcji użytkownika. Pakiet można przekazać dowolnemu modelowi/agentowi zdolnemu czytać Markdown, Python i konfigurację oraz korzystać z narzędzi testowych.

---

# Prompt startowy dla nowego modelu lub wątku

Przejmujesz projekt AI. Przeczytaj dołączony `AI_PROJECT_HANDOFF.md` albo odpowiadające mu pliki dokumentacji oraz załączony bieżący kod i konfigurację. Odpowiadaj po polsku, zwięźle i technicznie.

Nie kontynuuj numerowania wcześniejszych poprawek bez sprawdzenia aktywnego kodu. Historyczne propozycje i wypowiedzi poprzedniego asystenta nie stanowią dowodu wdrożenia.

Użytkownik oczekuje zmian obejmujących wszystkie konieczne zależności. Nie ograniczaj się do jednej zmiany na raz; przygotuj spójny zestaw obejmujący wymagane UI, API, dane i retrieval. Zachowaj Privacy Gateway, Approval Gate, firewall dokumentowy oraz izolację użytkowników.

Zgłoszone problemy: OpenAI zwraca poprawną odpowiedź, ale postęp analizy nie jest stale i czytelnie widoczny; nadal brakuje przycisków lekcji; lokalna Gemma daje błędne i zmienne odpowiedzi. Nie wykazano pełnego przepływu weryfikacja → kandydat → decyzja → wykorzystanie zatwierdzonej lekcji.

Pierwsze działanie:

1. Porównaj dokumentację ze źródłami i migawką serwera. Wskaż fakty, konflikty i brakujące dane w jednej krótkiej tabeli. Nie pytaj ponownie o dane obecne w paczce.
2. Prześledź cały łańcuch akcji: klasa/metadane, aktywacja i uprawnienia, model widziany przez UI, odpowiedź API, frontend. Brak przypadku nie jest wystarczającą diagnozą braku przycisku.
3. Prześledź weryfikację: docelowe identyfikatory, zgoda i brama, HTTP/async, zdarzenia, zapis raportu, timeout oraz powrót po rozłączeniu. Nie utożsamiaj toastu ze stanem operacji.
4. Sprawdź, czy przypadek już powstaje i jak zatwierdzona lekcja jest pobierana do kontekstu. Nie twórz drugiego mechanizmu, jeśli istniejący wymaga tylko naprawy.
5. Przygotuj patch na rzeczywistym kodzie, testy przepływu, zgodność wersji, plan wdrożenia i wycofania oraz aktualizację dokumentacji. Oznacz testy niewykonane.

Jeżeli brak kodu lub metadanych uniemożliwia diagnozę, wykonaj niezależną analizę dostępnych danych i poproś zbiorczo o konkretny brakujący zestaw z `SOURCE_INPUTS.md`. Nie wymyślaj endpointów, portów ani wyników testów. Nie podmieniaj modelu lokalnego, nie aktualizuj całej platformy i nie omijaj zabezpieczeń jako pierwszego eksperymentu.

Pierwsza odpowiedź ma zawierać ustalenia i jedno zbiorcze następne działanie. Kolejne odpowiedzi: rezultat, dowód, zmienione granice, walidacja i pozostające ograniczenia. Oceniaj postęp według `ACCEPTANCE_TESTS.md`.

---

# Materiały do diagnozy i przekazania kodu

Ten pakiet można wykorzystać od razu do uporządkowania pracy. Rzeczywiste poprawki wymagają poniższych materiałów. Nie trzeba przesyłać całej historii rozmów.

## Minimalny zestaw — zbierz razem

| Materiał | Potrzebny zakres | Cel |
| --- | --- | --- |
| Migawka serwera | `context.json` ze skryptu dla wybranych kontenerów | Ustalenie obrazu, stanu i granic usług |
| Open WebUI | Dokładna wersja; wyeksportowany aktywny kod obu funkcji oraz funkcji zmieniających etykiety akcji | Zgodność i rejestracja |
| Valves | Faktycznie zapisane wartości, bez sekretów; Active/Global/przypisania | Konfiguracja może przetrwać podmianę kodu |
| Model Secure Auto | ID wybranego modelu i jego definicja/przypisane funkcje | UI może korzystać z aliasu o innej konfiguracji |
| AI Broker | Obsługa `/external/verify`, routing, normalizacja wyniku i zapis przypadków; zależne importy | Cały przepływ wyniku |
| Privacy Gateway | Istotne endpointy, polityka zgody/redakcji, timeout i aliasy | Zachowanie zabezpieczeń |
| Learning Store | Schemat/migracje, tworzenie przypadku, decyzje, retrieval/wstrzyknięcie kontekstu | Wykazanie zastosowania lekcji |
| Usługi | Compose/Dockerfile/pliki zależności, sieci i montowania; bez `.env` i wartości kluczy | Zgodność i wdrożenie |

Jeżeli projekt jest w git, podaj commit i wybrane źródła; nie wysyłaj całego `.git`. Jeżeli kod funkcji jest w bazie Open WebUI, prześlij eksport aktywnej funkcji, nie wyłącznie plik proponowany wcześniej przez asystenta.

## Jeden reprodukowalny przebieg

Użyj syntetycznego pytania. Zanotuj: model, użytkownik testowy, czas kliknięcia, ID czatu/wiadomości, moment odpowiedzi, obserwowane miejsce i czas widoczności statusu oraz stan po odświeżeniu. Dodaj logi z tego krótkiego przedziału z wyciętymi sekretami i treścią prywatną.

W narzędziach deweloperskich przeglądarki sprawdź odpowiedź z metadanymi wybranego modelu, żądanie uruchamiające Action oraz zdarzenia dotyczące statusu/wyniku. Do przekazania wystarczą istotne fragmenty pozbawione Cookie, Authorization, tokenów i danych osobowych. Nie eksportuj pełnego HAR z aktywnej sesji bez kontroli zawartości. Jeśli nie wiadomo, który endpoint dostarcza metadane w tej wersji, odszukaj go w rzeczywistych żądaniach, zamiast podstawiać nazwę z innej wersji.

## Materiały do poprawy Gemmy

Dokładny model/alias i Modelfile lub jego odpowiednik, runtime i wersja, kwantyzacja, kontekst, limity tokenów, temperatura i inne ustawienia rzeczywiście użyte, prompt systemowy i dołączany kontekst, GPU/RAM oraz 3–5 syntetycznych przykładów błędnej odpowiedzi. Dla porównania shell/WebUI zapisz różnice żądań. Nie zakładaj, że wartości widoczne w formularzu są tymi, które ostatecznie otrzymał model.

## Zasady pakowania

Nie dołączaj `.env`, kluczy API/SSH, ciasteczek, dumpów rozmów ani produkcyjnej bazy lekcji. W konfiguracji pozostaw nazwy zmiennych i zastąp poufne wartości `<REDACTED>`. Jeżeli błąd wymaga danych z bazy, przygotuj schemat i syntetyczny rekord. Ogólny regex nie gwarantuje usunięcia wszystkich sekretów z dowolnego logu — przegląd jest konieczny.

Nie trzeba na tym etapie zmieniać produkcji. Dane służą ustaleniu faktycznej diagnozy oraz przygotowaniu jednego spójnego zestawu poprawek.

---

# Źródła techniczne i granice ich zastosowania

Sprawdzono 2026-10-12. Są to bieżące materiały oficjalne; wersja Open WebUI użytkownika nie została ustalona. Przed poprawką użyć dokumentacji i kodu zgodnego z zainstalowaną wersją.

## Open WebUI Action

[Action Function](https://docs.openwebui.com/features/extensibility/plugin/functions/action/)

Punkty do porównania z wdrożeniem: `class Action`; `actions` jako atrybut klasy/instancji; aktywacja przy modelu/globalnie; aktualizacje w `messages` z ID wiadomości; Action działa w żądaniu HTTP. To nie potwierdza przyczyny błędu instalacji użytkownika.

## Open WebUI Events

[Events and Event Emitters](https://docs.openwebui.com/features/extensibility/plugin/development/events/)

Dokumentacja rozróżnia `notification` dla powiadomienia i `status` dla stanu. Dla sekwencji statusów przewiduje końcowe `done: true`. Opisuje także aktualizację treści wiadomości. Samo emitowanie zdarzenia nie dowodzi poprawnego wskazania celu, wyświetlenia ani trwałego zapisu w danej instalacji. Ten pakiet nie zakłada, że native status spełni wymaganie położenia na dole; wybór UI wymaga sprawdzenia rzeczywistego frontendu.

## Materiały projektu

Źródłem faktów o zachowaniu są zgłoszenia użytkownika w dostarczonym kontekście rozmowy. Wersje z wcześniejszych opisów asystenta są oznaczone jako historyczne. Nie odczytywano bieżącego serwera ani plików wcześniejszych rozmów.

---

# Rejestr zmian projektu

## 2026-10-12 — pakiet dokumentacyjny 1.0

- Przygotowano stan wiedzy, mapę zależności, instrukcje, plan integracji, testy odbioru, prompt przekazania i porównanie modeli.
- Zastąpiono regułę jednej zmiany na raz spójnymi zestawami zmian obejmującymi wymagane zależności.
- Przygotowano skrypt diagnostyczny zbierający metadane i zasoby, bez konfiguracji zawierającej sekrety i bez treści rozmów.
- Nie zmieniono serwera. Nie potwierdzono naprawy postępu, przycisków ani jakości Gemmy.
- Bieżąca dokumentacja Open WebUI została sprawdzona jako odniesienie; wersja użytkownika pozostaje nieustalona.
- Walidacja skryptu: składnia i scenariusze symulowane poprawnego/częściowego odczytu, deduplikacji wyboru, odmowy nadpisania i uprawnień pliku. Bez testu rzeczywistego demona Docker i jego szablonów.

## Wzór następnego wpisu

```text
Data / identyfikator zestawu:
Problem i dowód:
Wersje / commity przed i po:
Dotknięte komponenty i kontrakty:
Zmiana danych / migracja:
Wdrożenie i kolejność:
Testy: PASS / FAIL / NOT RUN + dowód:
Wpływ na jakość i czas:
Rollback (kod + dane):
Pozostałe problemy:
Aktualizacja AI_SYSTEM_STATE i DEPENDENCIES:
```

---

# Projekt AI — pakiet optymalizacji i przekazania

Wersja pakietu: 1.0, 12 października 2026. Dokumentacja startowa, nie raport z audytu serwera.

## Co jest gotowe

Pakiet porządkuje wiedzę o projekcie, zachowuje zależności, definiuje wspólne kryteria naprawy i umożliwia rozpoczęcie pracy w nowej rozmowie albo z innym modelem. Nie zawiera aktualnego kodu instalacji, ponieważ nie został udostępniony w tej rozmowie. Nie wykonano zmian na serwerze ani testów działającego systemu.

| Plik | Zastosowanie |
| --- | --- |
| `AI_SYSTEM_STATE.md` | Aktualnie dostępne fakty, historia i luki |
| `PROJECT_INSTRUCTIONS.md` | Instrukcje do wklejenia w ustawienia projektu |
| `DEPENDENCIES.md` | Mapa komponentów i kontraktów |
| `INTEGRATION_PLAN.md` | Spójne zestawy zmian i kolejność diagnozy |
| `ACCEPTANCE_TESTS.md` | Testy całego przepływu oraz regresji |
| `MODEL_EVALUATION.md` | Sposób wyboru sprawniejszego modelu prowadzącego |
| `HANDOFF_PROMPT.md` | Gotowy prompt do nowego modelu lub wątku |
| `SOURCE_INPUTS.md` | Lista danych potrzebnych do pracy na rzeczywistym kodzie |
| `CHANGELOG.md` | Historia i wzór rejestracji zmian |
| `TECHNICAL_REFERENCES.md` | Oficjalne źródła i zgodność wersji |
| `collect_context.py` | Lokalna diagnostyka metadanych Docker i zasobów |
| `evaluation_results.csv` | Pusty arkusz wyników porównania modeli |
| `SHA256SUMS.txt` | Sumy kontrolne plików pakietu |

## Jak zacząć

1. Wklej `PROJECT_INSTRUCTIONS.md` w instrukcje projektu. To zastępuje wcześniejszą zasadę „jedna zmiana na raz”.
2. Do nowego wątku lub innego modelu dołącz `AI_PROJECT_HANDOFF.md` oraz aktualne materiały z listy `SOURCE_INPUTS.md`. Dokument zbiorczy jest dostarczony obok archiwum, a jego kopia znajduje się w archiwum.
3. Wklej `HANDOFF_PROMPT.md`. Model ma najpierw zidentyfikować stan wdrożony, konflikty wersji i brakujące dowody.
4. Uzupełnij migawkę serwera poniższym skryptem. Nie wykonuj aktualizacji Open WebUI ani podmiany modelu lokalnego przed ustaleniem punktu odniesienia.
5. Prowadź pracę przez spójne zestawy zmian opisane w `INTEGRATION_PLAN.md`. Każdy zestaw może obejmować wiele komponentów i ma jeden wspólny wynik do potwierdzenia.

## Zebranie stanu serwera

Wypakuj archiwum na serwerze, przejdź do `AI_PROJECT_PACKAGE` i wykonaj:

```bash
python3 collect_context.py --out ai-context-inventory
```

W `ai-context-inventory/context.json` znajdziesz nazwy kontenerów. Następnie wybierz kontenery należące do projektu. Poniższe nazwy są miejscami do zastąpienia, nie ustaloną konfiguracją:

```bash
python3 collect_context.py --containers NAZWA_WEBUI NAZWA_BROKERA NAZWA_GATEWAY --out ai-context-project
```

Uruchom to jako użytkownik, który już ma dostęp do Docker. Nie zmieniaj uprawnień gniazda Docker na potrzeby diagnostyki. Katalog wyniku musi być nowy; skrypt odmawia nadpisania istniejącego.

Skrypt nie restartuje kontenerów, nie pobiera modeli i nie odpytuje zewnętrznych usług. Nie zbiera zmiennych środowiskowych, pełnych logów, treści rozmów, poleceń startowych kontenerów ani plików konfiguracji. Raport zawiera m.in. nazwy, obrazy, identyfikatory obrazów, stan, porty, nazwy sieci i informacje o montowaniach wybranych kontenerów. Może ujawnić szczegóły wewnętrznej infrastruktury — przejrzyj go przed przekazaniem poza projekt. Nie zastępuje eksportu kodu funkcji, Valves, informacji o modelach i obserwacji przeglądarki.

Jeśli Docker nie jest dostępny, skrypt zapisze tę informację. Brak uprawnień lub częściowy wynik nie jest potwierdzeniem zdrowia usług. Kod wyjścia 0 oznacza kompletne wykonanie wybranych pomiarów, 2 — częściową diagnostykę, 1 — błąd zapisu/użycia. Pomiar GPU jest opcjonalny.

## Co oznacza przekazanie do innego modelu

Zmiana modelu prowadzącego projekt nie wymaga zmiany Gemmy, routera, bramy prywatności ani danych Learning Store. Nowy model otrzymuje tę samą dokumentację i kod. Wymianę lokalnego workera traktujemy jako osobne przedsięwzięcie: zgodność API, jakość, zasoby, kontekst i regresja. Nie zakładamy, że większe okno kontekstu lub wyższy poziom rozumowania automatycznie rozwiąże problemy integracyjne.

Pakiet nie obiecuje, że konkretny model będzie lepszy. `MODEL_EVALUATION.md` pozwala wybrać go na podstawie wyników zadań tego projektu.

## Sprawdzenie tego pakietu

Skrypt przeszedł kontrolę składni Python i symulacje: poprawny odczyt, brak Docker, wybór kontenera bez duplikatów, odmowa nadpisania katalogu oraz ograniczone uprawnienia zapisywanego raportu. Sprawdzono archiwum i sumy kontrolne. Nie sprawdzono szablonów na rzeczywistym Docker ani Open WebUI, usług i modeli użytkownika; to wymaga uruchomienia diagnostyki na serwerze. Symulacja nie jest testem produkcji.
