# Materiały do diagnozy i przekazania kodu

Ten pakiet można wykorzystać od razu do uporządkowania pracy. Rzeczywiste poprawki wymagają poniższych materiałów. Nie trzeba przesyłać całej historii rozmów.

## Minimalny zestaw — zbierz razem

| Materiał | Potrzebny zakres | Cel |
| --- | --- | --- |
| Migawka serwera | `context.json` ze skryptu dla wybranych kontenerów | Ustalenie obrazu, stanu i granic usług |
| Open WebUI | Dokładna wersja; wyeksportowany aktywny kod obu funkcji oraz funkcji zmieniających etykiety akcji | Zgodność i rejestracja |
| Valves | Faktycznie zapisane wartości, bez sekretów; Active/Global/przypisania | Konfiguracja może przetrwać podmianę kodu |
| Model Secure Auto | ID wybranego modelu i jego definicja/przypisane funkcje | UI może korzystać z aliasu o innej konfiguracji |
| AI Broker | Obsługa `/external/verify`, routing, normalizacja wyniku i zapis przypadków; zależne importy | Cały przepływ wyniku |
| Privacy Gateway | Istotne endpointy, polityka zgody/redakcji, timeout i aliasy | Zachowanie zabezpieczeń |
| Learning Store | Schemat/migracje, tworzenie przypadku, decyzje, retrieval/wstrzyknięcie kontekstu | Wykazanie zastosowania lekcji |
| Usługi | Compose/Dockerfile/pliki zależności, sieci i montowania; bez `.env` i wartości kluczy | Zgodność i wdrożenie |

Jeżeli projekt jest w git, podaj commit i wybrane źródła; nie wysyłaj całego `.git`. Jeżeli kod funkcji jest w bazie Open WebUI, prześlij eksport aktywnej funkcji, nie wyłącznie plik proponowany wcześniej przez asystenta.

## Jeden reprodukowalny przebieg

Użyj syntetycznego pytania. Zanotuj: model, użytkownik testowy, czas kliknięcia, ID czatu/wiadomości, moment odpowiedzi, obserwowane miejsce i czas widoczności statusu oraz stan po odświeżeniu. Dodaj logi z tego krótkiego przedziału z wyciętymi sekretami i treścią prywatną.

W narzędziach deweloperskich przeglądarki sprawdź odpowiedź z metadanymi wybranego modelu, żądanie uruchamiające Action oraz zdarzenia dotyczące statusu/wyniku. Do przekazania wystarczą istotne fragmenty pozbawione Cookie, Authorization, tokenów i danych osobowych. Nie eksportuj pełnego HAR z aktywnej sesji bez kontroli zawartości. Jeśli nie wiadomo, który endpoint dostarcza metadane w tej wersji, odszukaj go w rzeczywistych żądaniach, zamiast podstawiać nazwę z innej wersji.

## Materiały do poprawy Gemmy

Dokładny model/alias i Modelfile lub jego odpowiednik, runtime i wersja, kwantyzacja, kontekst, limity tokenów, temperatura i inne ustawienia rzeczywiście użyte, prompt systemowy i dołączany kontekst, GPU/RAM oraz 3–5 syntetycznych przykładów błędnej odpowiedzi. Dla porównania shell/WebUI zapisz różnice żądań. Nie zakładaj, że wartości widoczne w formularzu są tymi, które ostatecznie otrzymał model.

## Zasady pakowania

Nie dołączaj `.env`, kluczy API/SSH, ciasteczek, dumpów rozmów ani produkcyjnej bazy lekcji. W konfiguracji pozostaw nazwy zmiennych i zastąp poufne wartości `<REDACTED>`. Jeżeli błąd wymaga danych z bazy, przygotuj schemat i syntetyczny rekord. Ogólny regex nie gwarantuje usunięcia wszystkich sekretów z dowolnego logu — przegląd jest konieczny.

Nie trzeba na tym etapie zmieniać produkcji. Dane służą ustaleniu faktycznej diagnozy oraz przygotowaniu jednego spójnego zestawu poprawek.
