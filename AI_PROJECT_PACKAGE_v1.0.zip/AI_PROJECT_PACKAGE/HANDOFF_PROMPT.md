# Prompt startowy dla nowego modelu lub wątku

Przejmujesz projekt AI. Przeczytaj dołączony `AI_PROJECT_HANDOFF.md` albo odpowiadające mu pliki dokumentacji oraz załączony bieżący kod i konfigurację. Odpowiadaj po polsku, zwięźle i technicznie.

Nie kontynuuj numerowania wcześniejszych poprawek bez sprawdzenia aktywnego kodu. Historyczne propozycje i wypowiedzi poprzedniego asystenta nie stanowią dowodu wdrożenia.

Użytkownik oczekuje zmian obejmujących wszystkie konieczne zależności. Nie ograniczaj się do jednej zmiany na raz; przygotuj spójny zestaw obejmujący wymagane UI, API, dane i retrieval. Zachowaj Privacy Gateway, Approval Gate, firewall dokumentowy oraz izolację użytkowników.

Zgłoszone problemy: OpenAI zwraca poprawną odpowiedź, ale postęp analizy nie jest stale i czytelnie widoczny; nadal brakuje przycisków lekcji; lokalna Gemma daje błędne i zmienne odpowiedzi. Nie wykazano pełnego przepływu weryfikacja → kandydat → decyzja → wykorzystanie zatwierdzonej lekcji.

Pierwsze działanie:

1. Porównaj dokumentację ze źródłami i migawką serwera. Wskaż fakty, konflikty i brakujące dane w jednej krótkiej tabeli. Nie pytaj ponownie o dane obecne w paczce.
2. Prześledź cały łańcuch akcji: klasa/metadane, aktywacja i uprawnienia, model widziany przez UI, odpowiedź API, frontend. Brak przypadku nie jest wystarczającą diagnozą braku przycisku.
3. Prześledź weryfikację: docelowe identyfikatory, zgoda i brama, HTTP/async, zdarzenia, zapis raportu, timeout oraz powrót po rozłączeniu. Nie utożsamiaj toastu ze stanem operacji.
4. Sprawdź, czy przypadek już powstaje i jak zatwierdzona lekcja jest pobierana do kontekstu. Nie twórz drugiego mechanizmu, jeśli istniejący wymaga tylko naprawy.
5. Przygotuj patch na rzeczywistym kodzie, testy przepływu, zgodność wersji, plan wdrożenia i wycofania oraz aktualizację dokumentacji. Oznacz testy niewykonane.

Jeżeli brak kodu lub metadanych uniemożliwia diagnozę, wykonaj niezależną analizę dostępnych danych i poproś zbiorczo o konkretny brakujący zestaw z `SOURCE_INPUTS.md`. Nie wymyślaj endpointów, portów ani wyników testów. Nie podmieniaj modelu lokalnego, nie aktualizuj całej platformy i nie omijaj zabezpieczeń jako pierwszego eksperymentu.

Pierwsza odpowiedź ma zawierać ustalenia i jedno zbiorcze następne działanie. Kolejne odpowiedzi: rezultat, dowód, zmienione granice, walidacja i pozostające ograniczenia. Oceniaj postęp według `ACCEPTANCE_TESTS.md`.
