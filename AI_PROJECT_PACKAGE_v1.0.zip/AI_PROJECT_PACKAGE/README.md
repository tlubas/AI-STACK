# Projekt AI — pakiet optymalizacji i przekazania

Wersja pakietu: 1.0, 12 października 2026. Dokumentacja startowa, nie raport z audytu serwera.

## Co jest gotowe

Pakiet porządkuje wiedzę o projekcie, zachowuje zależności, definiuje wspólne kryteria naprawy i umożliwia rozpoczęcie pracy w nowej rozmowie albo z innym modelem. Nie zawiera aktualnego kodu instalacji, ponieważ nie został udostępniony w tej rozmowie. Nie wykonano zmian na serwerze ani testów działającego systemu.

| Plik | Zastosowanie |
| --- | --- |
| `AI_SYSTEM_STATE.md` | Aktualnie dostępne fakty, historia i luki |
| `PROJECT_INSTRUCTIONS.md` | Instrukcje do wklejenia w ustawienia projektu |
| `DEPENDENCIES.md` | Mapa komponentów i kontraktów |
| `INTEGRATION_PLAN.md` | Spójne zestawy zmian i kolejność diagnozy |
| `ACCEPTANCE_TESTS.md` | Testy całego przepływu oraz regresji |
| `MODEL_EVALUATION.md` | Sposób wyboru sprawniejszego modelu prowadzącego |
| `HANDOFF_PROMPT.md` | Gotowy prompt do nowego modelu lub wątku |
| `SOURCE_INPUTS.md` | Lista danych potrzebnych do pracy na rzeczywistym kodzie |
| `CHANGELOG.md` | Historia i wzór rejestracji zmian |
| `TECHNICAL_REFERENCES.md` | Oficjalne źródła i zgodność wersji |
| `collect_context.py` | Lokalna diagnostyka metadanych Docker i zasobów |
| `evaluation_results.csv` | Pusty arkusz wyników porównania modeli |
| `SHA256SUMS.txt` | Sumy kontrolne plików pakietu |

## Jak zacząć

1. Wklej `PROJECT_INSTRUCTIONS.md` w instrukcje projektu. To zastępuje wcześniejszą zasadę „jedna zmiana na raz”.
2. Do nowego wątku lub innego modelu dołącz `AI_PROJECT_HANDOFF.md` oraz aktualne materiały z listy `SOURCE_INPUTS.md`. Dokument zbiorczy jest dostarczony obok archiwum, a jego kopia znajduje się w archiwum.
3. Wklej `HANDOFF_PROMPT.md`. Model ma najpierw zidentyfikować stan wdrożony, konflikty wersji i brakujące dowody.
4. Uzupełnij migawkę serwera poniższym skryptem. Nie wykonuj aktualizacji Open WebUI ani podmiany modelu lokalnego przed ustaleniem punktu odniesienia.
5. Prowadź pracę przez spójne zestawy zmian opisane w `INTEGRATION_PLAN.md`. Każdy zestaw może obejmować wiele komponentów i ma jeden wspólny wynik do potwierdzenia.

## Zebranie stanu serwera

Wypakuj archiwum na serwerze, przejdź do `AI_PROJECT_PACKAGE` i wykonaj:

```bash
python3 collect_context.py --out ai-context-inventory
```

W `ai-context-inventory/context.json` znajdziesz nazwy kontenerów. Następnie wybierz kontenery należące do projektu. Poniższe nazwy są miejscami do zastąpienia, nie ustaloną konfiguracją:

```bash
python3 collect_context.py --containers NAZWA_WEBUI NAZWA_BROKERA NAZWA_GATEWAY --out ai-context-project
```

Uruchom to jako użytkownik, który już ma dostęp do Docker. Nie zmieniaj uprawnień gniazda Docker na potrzeby diagnostyki. Katalog wyniku musi być nowy; skrypt odmawia nadpisania istniejącego.

Skrypt nie restartuje kontenerów, nie pobiera modeli i nie odpytuje zewnętrznych usług. Nie zbiera zmiennych środowiskowych, pełnych logów, treści rozmów, poleceń startowych kontenerów ani plików konfiguracji. Raport zawiera m.in. nazwy, obrazy, identyfikatory obrazów, stan, porty, nazwy sieci i informacje o montowaniach wybranych kontenerów. Może ujawnić szczegóły wewnętrznej infrastruktury — przejrzyj go przed przekazaniem poza projekt. Nie zastępuje eksportu kodu funkcji, Valves, informacji o modelach i obserwacji przeglądarki.

Jeśli Docker nie jest dostępny, skrypt zapisze tę informację. Brak uprawnień lub częściowy wynik nie jest potwierdzeniem zdrowia usług. Kod wyjścia 0 oznacza kompletne wykonanie wybranych pomiarów, 2 — częściową diagnostykę, 1 — błąd zapisu/użycia. Pomiar GPU jest opcjonalny.

## Co oznacza przekazanie do innego modelu

Zmiana modelu prowadzącego projekt nie wymaga zmiany Gemmy, routera, bramy prywatności ani danych Learning Store. Nowy model otrzymuje tę samą dokumentację i kod. Wymianę lokalnego workera traktujemy jako osobne przedsięwzięcie: zgodność API, jakość, zasoby, kontekst i regresja. Nie zakładamy, że większe okno kontekstu lub wyższy poziom rozumowania automatycznie rozwiąże problemy integracyjne.

Pakiet nie obiecuje, że konkretny model będzie lepszy. `MODEL_EVALUATION.md` pozwala wybrać go na podstawie wyników zadań tego projektu.

## Sprawdzenie tego pakietu

Skrypt przeszedł kontrolę składni Python i symulacje: poprawny odczyt, brak Docker, wybór kontenera bez duplikatów, odmowa nadpisania katalogu oraz ograniczone uprawnienia zapisywanego raportu. Sprawdzono archiwum i sumy kontrolne. Nie sprawdzono szablonów na rzeczywistym Docker ani Open WebUI, usług i modeli użytkownika; to wymaga uruchomienia diagnostyki na serwerze. Symulacja nie jest testem produkcji.
