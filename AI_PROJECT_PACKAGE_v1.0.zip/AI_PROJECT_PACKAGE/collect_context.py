#!/usr/bin/env python3
"""Read-only Docker/GPU metadata collector. Python 3.8+, no dependencies.

Writes only to a newly created output directory. Never collects environment,
container command lines, application logs, credentials or conversation content.
"""

import argparse
import datetime
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys


INVENTORY_FORMAT = (
    '{"id":{{json .ID}},"name":{{json .Names}},'
    '"image":{{json .Image}},"status":{{json .Status}}}'
)
INSPECT_FORMAT = (
    '{"id":{{json .Id}},"name":{{json .Name}},'
    '"image_reference":{{json .Config.Image}},"image_id":{{json .Image}},'
    '"status":{{json .State.Status}},"running":{{json .State.Running}},'
    '"exit_code":{{json .State.ExitCode}},'
    '"restart_count":{{json .RestartCount}},'
    '"ports":{{json .NetworkSettings.Ports}},'
    '"compose_project":{{json (index .Config.Labels "com.docker.compose.project")}},'
    '"compose_service":{{json (index .Config.Labels "com.docker.compose.service")}}}'
)
STATS_FORMAT = (
    '{"name":{{json .Name}},"cpu":{{json .CPUPerc}},'
    '"memory_usage":{{json .MemUsage}},"memory_percent":{{json .MemPerc}},'
    '"network_io":{{json .NetIO}},"block_io":{{json .BlockIO}},'
    '"pids":{{json .PIDs}}}'
)
NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")


def command(args, timeout=20):
    """Return output from allowlisted invocations; do not expose raw stderr."""
    try:
        proc = subprocess.run(
            args, capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="replace", check=False,
        )
    except FileNotFoundError:
        return {"ok": False, "error": "command_not_found"}, ""
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout", "timeout_seconds": timeout}, ""
    except OSError as exc:
        return {"ok": False, "error": "os_error", "errno": exc.errno}, ""
    if proc.returncode != 0:
        return {"ok": False, "error": "nonzero_exit", "exit_code": proc.returncode}, ""
    return {"ok": True}, proc.stdout


def json_lines(args, timeout=20):
    state, output = command(args, timeout)
    if not state["ok"]:
        return state
    try:
        records = [json.loads(line) for line in output.splitlines() if line.strip()]
    except (ValueError, TypeError):
        return {"ok": False, "error": "unexpected_format"}
    return {"ok": True, "records": records}


def gpu_metadata():
    if not shutil.which("nvidia-smi"):
        return {"ok": True, "available": False, "note": "optional_measurement"}
    state, output = command([
        "nvidia-smi", "--query-gpu=name,memory.total,driver_version",
        "--format=csv,noheader,nounits",
    ])
    if state["ok"]:
        state.update({"available": True, "name_memory_mib_driver": output.strip().splitlines()})
    return state


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", default="ai-context", help="New output directory; never overwrite")
    parser.add_argument("--containers", nargs="+", default=[], metavar="NAME",
                        help="Exact Docker container names/IDs for additional metadata")
    args = parser.parse_args(argv)
    for name in args.containers:
        if not NAME_PATTERN.fullmatch(name):
            parser.error("Invalid container name/ID: use letters, digits, dot, underscore or hyphen")
    selected = list(dict.fromkeys(args.containers))
    output_dir = Path(args.out).expanduser().absolute()
    try:
        output_dir.mkdir(mode=0o700, parents=False, exist_ok=False)
    except OSError:
        print("Cannot create output directory. Choose a new directory in an existing writable parent.", file=sys.stderr)
        return 1

    os.umask(0o077)
    report = {
        "schema_version": 1,
        "collected_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "scope": "metadata_only_no_logs_no_env_no_prompts",
        "host": {
            "os": platform.system(), "release": platform.release(),
            "architecture": platform.machine(), "python": platform.python_version(),
            "logical_cpu_count": os.cpu_count(),
        },
        "selected_containers": selected,
        "gpu": gpu_metadata(),
    }
    version_state, version_output = command(["docker", "version", "--format", "{{.Server.Version}}"])
    if version_state["ok"]:
        version_state["server_version"] = version_output.strip()
    report["docker_version"] = version_state
    report["inventory"] = json_lines(["docker", "ps", "--all", "--format", INVENTORY_FORMAT])
    report["containers"] = []
    partial = not version_state["ok"] or not report["inventory"]["ok"]

    for name in selected:
        item = {"requested_name_or_id": name}
        inspected = json_lines(["docker", "container", "inspect", "--format", INSPECT_FORMAT, name])
        item["metadata"] = inspected
        if not inspected["ok"] or len(inspected.get("records", [])) != 1:
            partial = True
            item["detail_note"] = "Inspection failed or did not identify exactly one container"
            report["containers"].append(item)
            continue

        metadata = inspected["records"][0]
        # Inspect only the selected projections. Do not request full inspect output.
        mount_format = (
            '{{range .Mounts}}{"type":{{json .Type}},"name":{{json .Name}},'
            '"source":{{json .Source}},"destination":{{json .Destination}},'
            '"read_write":{{json .RW}}}{{println}}{{end}}'
        )
        network_format = '{{range $name, $data := .NetworkSettings.Networks}}{{json $name}}{{println}}{{end}}'
        item["mounts"] = json_lines(["docker", "container", "inspect", "--format", mount_format, name])
        item["networks"] = json_lines(["docker", "container", "inspect", "--format", network_format, name])
        digest_state, digest_output = command([
            "docker", "image", "inspect", "--format", "{{json .RepoDigests}}", metadata["image_id"],
        ])
        if digest_state["ok"]:
            try:
                digest_state["repo_digests"] = json.loads(digest_output) or []
            except ValueError:
                digest_state = {"ok": False, "error": "unexpected_format"}
        item["image_digests"] = digest_state
        if metadata.get("running"):
            item["stats"] = json_lines([
                "docker", "stats", "--no-stream", "--format", STATS_FORMAT, name,
            ], timeout=25)
        else:
            item["stats"] = {"ok": True, "skipped": "container_not_running"}
        if any(not item[key]["ok"] for key in ("mounts", "networks", "image_digests", "stats")):
            partial = True
        report["containers"].append(item)

    report["collection_status"] = "partial" if partial else "complete"
    report["limits"] = [
        "No application source code or Valves collected",
        "Image tag alone does not prove the running application version",
        "A running container does not prove application health or UI behavior",
        "Resource values are one snapshot, not a performance benchmark",
        "Inventory contains container metadata from the Docker daemon visible to this user",
        "Raw command errors omitted; diagnose daemon access locally if needed",
        "GPU metadata is optional and does not affect collection completeness",
    ]
    path = output_dir / "context.json"
    try:
        with path.open("x", encoding="utf-8") as handle:
            json.dump(report, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
    except OSError:
        print("Could not write context.json.", file=sys.stderr)
        return 1
    print("Report: {}".format(path))
    print("Collection: {}. Inspect the report before sharing.".format(report["collection_status"]))
    return 2 if partial else 0


if __name__ == "__main__":
    sys.exit(main())
