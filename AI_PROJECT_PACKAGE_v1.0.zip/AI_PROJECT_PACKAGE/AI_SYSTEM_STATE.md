# AI_SYSTEM_STATE

Data: 2026-10-12. Stan wiedzy z rozmowy, bez odczytu bieżącego serwera.

## Oznaczenia wiarygodności

| Oznaczenie | Znaczenie |
| --- | --- |
| U | Obserwacja zgłoszona przez użytkownika; niepowtórzona w tym środowisku |
| L | Fragment logu widoczny w kontekście; dowodzi wyłącznie zawartego zdarzenia |
| H | Historyczny opis lub propozycja wcześniejszego asystenta; wymaga weryfikacji |
| P | Nowa propozycja docelowa; nie jest wdrożoną funkcją |
| ? | Brak danych lub brak rozstrzygnięcia |

Historyczny opis asystenta nie jest dowodem aktualnego kodu. Zgłoszony brak przycisków nie dowodzi braku przypadków w bazie. Odpowiedź zewnętrzna nie dowodzi zapisania lekcji ani jej użycia przez Gemmę.

## Cel i ograniczenia

Lokalny system AI ma udzielać użytecznych odpowiedzi, zapewniać kontrolowaną weryfikację zewnętrzną oraz korzystać z zatwierdzonych korekt. Użytkownik oczekuje krótkiej, sprawnej pracy technicznej i zmian obejmujących cały wymagany zakres zależności. Priorytety: poprawność, bezpieczeństwo, stabilność, szybkość. Dotychczasowe wielokrotne poprawki funkcji bez potwierdzenia przyczyn nie przyniosły oczekiwanego wyniku.

## Komponenty

| Komponent | Rola wynikająca z rozmów | Stan/version evidence |
| --- | --- | --- |
| Open WebUI | Czat, funkcje Action, wyświetlanie raportu i decyzji | Komponent obecny; aktywna wersja ? |
| AI Broker | Orkiestracja lokalnego i zewnętrznego przetwarzania | H: 0.2.8 wymienione w opisie z 2026-10-09; aktywna wersja ? |
| Privacy Gateway | Kontrola danych wysyłanych zewnętrznie | H: 0.6.6 wymienione w opisie z 2026-10-09; aktywna wersja ? |
| LiteLLM | Pośrednictwo do modeli zewnętrznych | H: element opisanej architektury; obecność/wersja ? |
| Lokalny worker Gemma | Generowanie odpowiedzi lokalnych | H: Gemma3:12B; dokładny alias, kwantyzacja i parametry ? |
| Lokalny router | Wybór ścieżki obsługi | H: qwen2.5:1.5b; wdrożone reguły ? |
| Learning Store | Przypadki, zatwierdzenia, lekcje | Wymieniony w projekcie; schemat, lokalizacja i retrieval ? |
| OpenAI | Zewnętrzna weryfikacja i korekta | U: odpowiedź dotarła i była poprawna; dokładny model ? |
| Chat Store | Trwałe zapisanie wyniku w rozmowie | H: mechanizm wspominany w poprzednich poprawkach; sposób zapisu ? |

Nie ustalono nazw repozytoriów, nazw wszystkich kontenerów, portów, reverse proxy, rodzaju bazy ani montowań danych. Nie należy podstawiać wartości z typowych instalacji.

## Aktualne problemy

| ID | Dostępny dowód | Wniosek i niewiadoma |
| --- | --- | --- |
| EXT-RESULT | U: wcześniej powiadomienia bez efektu; później odpowiedź OpenAI dotarła | Co najmniej jeden przebieg zewnętrzny zakończył się wynikiem; trwałość po odświeżeniu ? |
| EXT-PROGRESS | U: popup oczekiwania znika; informacje bywały pod tytułem czatu; nadal brak oczekiwanego postępu | Nie potwierdzono czytelnego wskaźnika działającego przez cały czas |
| LEARN-BUTTONS | U: nadal brak przycisków zatwierdzania lekcji | Trzeba prześledzić kod → aktywację → metadane modelu → frontend |
| LEARN-LINK | H: wcześniejszy asystent stwierdził brak połączenia `/external/verify` z tworzeniem przypadku | Hipoteza, nie wynik audytu kodu; sprawdzić przed dopisywaniem zapisu |
| LOCAL-QUALITY | U: Gemma podaje błędne, zmienne odpowiedzi | Przyczyna ?; ustawienia, kontekst, retrieval i jakość modelu do rozdzielenia |
| WORKFLOW-SPEED | U: odpowiedzi asystenta prowadzącego projekt są zbyt wolne | Ograniczyć odtwarzanie historii i zbędną pracę; nie utożsamiać z opóźnieniem Gemmy |
| DOC-FIREWALL | U: firewall dokumentowy działa i nie wykonuje instrukcji z dokumentu | Zachować jako obowiązkową regresję |

## Historia funkcji

`Secure Auto External Verification`: wcześniejsze propozycje 0.1.1–0.1.5. Ostatnia opisana propozycja: 0.1.5, Valves `progress_ui_mode=inline`, `progress_interval_seconds=10`. Nie potwierdzono aktualnie aktywnego kodu ani zapisanych wartości Valves.

`Secure Auto Learning Actions`: historycznie wymieniono 0.1.3 oraz działania Zatwierdź, Odrzuć, Szczegóły. Nie potwierdzono struktury klasy, metadanych, przypisań do modelu ani aktywacji Global. Użytkownik zgłosił utrzymujący się brak przycisków.

L: widoczny fragment logu zawiera odpowiedź HTTP 200 na toggle `secure_auto_action_labels`, odczyt `secure_auto_learning_actions` i komunikat załadowania modułu `function_secure_auto_learning_actions`. To dowodzi obsługi tych żądań/załadowania modułu w tym momencie; nie dowodzi poprawnej listy akcji wysyłanej do przeglądarki ani wyświetlenia przycisków. `secure_auto_action_labels` i `secure_auto_learning_actions` to różne identyfikatory.

## Wymagany przepływ docelowy — P

1. Odpowiedź lokalna powiązana z konkretnym użytkownikiem, czatem i wiadomością.
2. Żądanie weryfikacji objęte istniejącymi kontrolami prywatności i zgody.
3. Czytelny stan oczekiwania przy sprawdzanej odpowiedzi aż do wyniku/błędu/anulowania.
4. Wynik zewnętrzny trwale powiązany z odpowiedzią źródłową.
5. Korekta wymagająca lekcji tworzy kandydata po walidacji, bez automatycznego zatwierdzenia.
6. Uprawniony użytkownik zatwierdza albo odrzuca właściwy przypadek.
7. Zatwierdzona lekcja jest pobierana do odpowiedniego przyszłego zapytania i jej użycie można wykazać.

Nie zakładamy treningu wag Gemmy. Dopóki kod nie pokaże inaczej, „uczenie” oznacza zapamiętanie i użycie zatwierdzonej wiedzy przez mechanizm kontekstu/retrieval. Sam zapis `approved` nie zmienia modelu.

## Najważniejsze brakujące dane

Aktywne źródła funkcji i Valves; wersja Open WebUI; metadane rzeczywiście wybranego modelu; obsługa `/external/verify`; kod Learning Store i wstrzykiwania lekcji; konfiguracja usług bez sekretów; jeden powtarzalny przebieg z czasami i identyfikatorami. Pełna lista w `SOURCE_INPUTS.md`.

Po każdym wdrożeniu aktualizować ten plik: wersja/commit → zmiana → dowód testu → nierozstrzygnięte kwestie. Nie usuwać negatywnych wyników testów ani mieszać propozycji ze stanem wdrożonym.
