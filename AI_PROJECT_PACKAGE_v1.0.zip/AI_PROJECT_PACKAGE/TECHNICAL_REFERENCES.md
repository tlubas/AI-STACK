# Źródła techniczne i granice ich zastosowania

Sprawdzono 2026-10-12. Są to bieżące materiały oficjalne; wersja Open WebUI użytkownika nie została ustalona. Przed poprawką użyć dokumentacji i kodu zgodnego z zainstalowaną wersją.

## Open WebUI Action

[Action Function](https://docs.openwebui.com/features/extensibility/plugin/functions/action/)

Punkty do porównania z wdrożeniem: `class Action`; `actions` jako atrybut klasy/instancji; aktywacja przy modelu/globalnie; aktualizacje w `messages` z ID wiadomości; Action działa w żądaniu HTTP. To nie potwierdza przyczyny błędu instalacji użytkownika.

## Open WebUI Events

[Events and Event Emitters](https://docs.openwebui.com/features/extensibility/plugin/development/events/)

Dokumentacja rozróżnia `notification` dla powiadomienia i `status` dla stanu. Dla sekwencji statusów przewiduje końcowe `done: true`. Opisuje także aktualizację treści wiadomości. Samo emitowanie zdarzenia nie dowodzi poprawnego wskazania celu, wyświetlenia ani trwałego zapisu w danej instalacji. Ten pakiet nie zakłada, że native status spełni wymaganie położenia na dole; wybór UI wymaga sprawdzenia rzeczywistego frontendu.

## Materiały projektu

Źródłem faktów o zachowaniu są zgłoszenia użytkownika w dostarczonym kontekście rozmowy. Wersje z wcześniejszych opisów asystenta są oznaczone jako historyczne. Nie odczytywano bieżącego serwera ani plików wcześniejszych rozmów.
