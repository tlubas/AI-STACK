# Kryteria odbioru i regresji

Plan testów; żadnego z poniższych wyników nie potwierdzono w tej rozmowie. Wykonać na reprezentatywnym środowisku z syntetycznymi danymi. Do testów UI korzystać z faktycznego konta i modelu użytkownika. Testy izolacji wymagają dwóch kont kontrolowanych przez wykonującego test.

| ID | Scenariusz | Oczekiwany wynik/dowód |
| --- | --- | --- |
| T01 | Nowa odpowiedź Secure Auto | Widoczne Zatwierdź/Odrzuć/Szczegóły; zidentyfikowane metadane modelu i funkcji |
| T02 | Akcja przy odpowiedzi bez przypadku | Jasny komunikat o braku kandydata; brak błędnego zapisu decyzji |
| T03 | Zewnętrzna odpowiedź po kontrolowanym opóźnieniu ok. 60 s | Stan widoczny przy wiadomości/panelu przez całe oczekiwanie; etap/czas aktualizowany, brak zmyślonego procentu |
| T04 | Wynik zewnętrzny i odświeżenie czatu | Raport pozostaje przy właściwej odpowiedzi; brak duplikatu i uszkodzenia pierwotnej treści |
| T05 | Błąd/timeout dostawcy | Stan końcowy czytelny, bez fałszywego sukcesu; pierwotna odpowiedź zachowana |
| T06 | Raport zawiera uzasadnioną korektę | Jeden poprawny kandydat według polityki, z powiązaniem źródła i raportu |
| T07 | Raport nie wymaga korekty | Brak pustej lekcji; właściwy wynik dla użytkownika |
| T08 | Ponowne kliknięcie/ponowienie żądania | Kontrolowane zachowanie; bez dwóch przypadków dla tego samego wyniku |
| T09 | Zatwierdzenie i ponowny odczyt | Stan zatwierdzony jest trwały, decyzja ma właściwego autora i źródło |
| T10 | Nowe podobne pytanie po zatwierdzeniu | Audyt potwierdza pobranie właściwej lekcji; ocena treści odpowiedzi oddzielona od samego retrieval |
| T11 | Odrzucona albo niezwiązana lekcja | Nie trafia do kontekstu jako obowiązująca zatwierdzona wiedza |
| T12 | Użytkownik B podaje ID czatu/przypadku A | Brak dostępu i zmiany danych A; brak ujawnienia treści |
| T13 | Regeneracja/edycja po rozpoczęciu weryfikacji | Wynik pozostaje związany ze źródłową wersją albo jest oznaczony jako nieaktualny |
| T14 | Rozłączenie karty w trakcie i powrót | Rzeczywisty stan możliwy do odtworzenia; brak fałszywego „zakończono” |
| T15 | Zapis lekcji nieudany przy poprawnym raporcie | Raport dostępny, ale UI ujawnia problem zapisu; ponowienie nie powiela wyników |
| T16 | Restart po zakończonym zapisie | Raport, przypadek i decyzja nadal istnieją i dają się odczytać |
| R01 | Tryb lokalny/bez zgody na wysyłkę | Brak nieautoryzowanej transmisji zewnętrznej |
| R02 | Dokument z próbą zmiany instrukcji systemu | Zachowanie istniejącego firewalla dokumentowego |
| R03 | Dane testowe podlegające redakcji | Brama nadal stosuje uzgodnioną politykę danych |
| R04 | Te same zadania shell vs WebUI | Zebrane rzeczywiste prompty i parametry bez sekretów; brak nowej niestabilności |
| R05 | Bazowe zadania przed/po na tym samym sprzęcie | Czas i jakość porównane przy równych warunkach; oddzielne zimne/rozgrzane przebiegi |

Do T03 użyć kontrolowanego opóźnienia w środowisku testowym. Nie obniżać stabilności produkcji ani obciążać płatnego dostawcy tylko do symulacji wolnego wyniku.

## Minimalny zapis wyniku

Każdy test: wersje/commity, konfiguracja, data i czas, ID korelacji, wejście syntetyczne, kroki, oczekiwany wynik, obserwowany wynik, PASS/FAIL/NOT RUN oraz ograniczenia. Logi zapisują etapy i identyfikatory; treść poufną zastąpić syntetycznym odpowiednikiem.

Przejście retrieval nie gwarantuje odpowiedzi poprawnej. W T10 ocenić osobno, czy lekcja została użyta i czy Gemma poprawnie ją zastosowała. Samo istnienie przycisku nie potwierdza autoryzacji ani zapisu decyzji.

Minimalny odbiór zgłoszonych problemów obejmuje T01–T16 i R01–R03 w zakresie zmienionego przepływu. Testy jakości/parametrów dodaje się przy zmianach generacji. Niewykonanych testów nie oznaczać jako zaliczone.
